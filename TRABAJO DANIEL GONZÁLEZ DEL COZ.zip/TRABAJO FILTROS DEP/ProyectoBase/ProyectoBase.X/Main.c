/*
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Config.h"
#include "Main.h"
#include "Func.h"

// M�s archivos de cabecera 

#include "LCD_display.h"
#include "dsp.h"
#include "math.h"

#define NUM_SAMPLES 256 //numero de muestras que vamos a tomar y luego cargar para obtener valores.
//---------------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;

float duty = 0.5;

float TRIANGULAR[NUM_SAMPLES];      // For storing ADC output
float SENOIDAL[NUM_SAMPLES];      // For storing ADC output
unsigned int posicion; // Recorrer� los arrays

// �Qu� variables voy a necesitar?
    
float maxsen, medsen, rmssen, maxtri, medtri, rmstri;

// Saldr�n en pantalla LCD

// Para el tema del filtro digital:

//_________ (Nombre del Archivo)FILTER _________________-

/* Variables externas generadas con la toolbox FilterDesigner de MatLab */
extern FIRStruct filtroPasoBandaFilter; // Aqu� cargar� el filtro FIR.

fractional FR_TRIANGULAR[NUM_SAMPLES];//almacenar triangular 
fractional FR_SENOIDAL[NUM_SAMPLES];//almacenar senoide
fractional filtradaTRI[NUM_SAMPLES];//Array de datos filtrados de la se�al triangular
fractional filtradaSEN[NUM_SAMPLES];//Array de datos filtrados de la se�al senoidal




//---------------------------------------------------------------------------
// Interrupci�n del CAD
//---------------------------------------------------------------------------

void __attribute__((interrupt, auto_psv)) _ADCInterrupt(void)
{
	IFS0bits.ADIF = 0;          // Clean flag
    
    // Con la informaci�n que lea el CAD, relleno mis arrays con la info que extrae de los buffers.
    // Tengo configurado el cad para que la informaci�n que me da sea unsigned int
    
    unsigned int tri = ADCBUFA;
    unsigned int seno = ADCBUFB;

    // Lo almaceno en los arrays, pero primero lo convierto a voltios. Por eso mis arrays son floats.
  
    TRIANGULAR[posicion]=1.0*tri*(5.0/4096.0);
    SENOIDAL[posicion]=1.0*seno*(5.0/4096.0);
    
    // Escalamos el flotante a fraccional
    
    FR_TRIANGULAR[posicion]=(fractional)tri;
    FR_SENOIDAL[posicion]=(fractional)seno;
 
    posicion++;
    
    if(posicion<NUM_SAMPLES){ //Aqu� se llama a la rutina del filtro
        FIR (NUM_SAMPLES, &filtradaTRI, &FR_TRIANGULAR, &filtroPasoBandaFilter);
        FIR (NUM_SAMPLES, &filtradaSEN, &FR_SENOIDAL, &filtroPasoBandaFilter);
    }
    
    if (posicion>NUM_SAMPLES){
       posicion=0;
    }
    
    ADCON1bits.ADON = 1;        // turn ADC ON
}

//---------------------------------------------------------------------------
// Interrupci�n del TMR1 - Aqu� es donde voy a configurar todo lo del LCD
//---------------------------------------------------------------------------


void __attribute__((interrupt, auto_psv)) _T1Interrupt(void){
    
    //Limpiamos flag y lo paramos.
    IFS0bits.T1IF = 0;
    T1CONbits.TON = 0;
    TMR1 = 0;
          
    InitLCD();  //Inicializamos el LCD
        
    // Guardar info de se�al triangular
    
    maxtri=Max(TRIANGULAR,NUM_SAMPLES);
    medtri=Avg(TRIANGULAR,NUM_SAMPLES);
    rmstri=Rms(TRIANGULAR,NUM_SAMPLES);
    
    // Guardar info de se�al senoidal
    
    maxsen=Max(SENOIDAL, NUM_SAMPLES);
    medsen=Avg(SENOIDAL, NUM_SAMPLES);
    rmssen=Rms(SENOIDAL, NUM_SAMPLES);
    
    // Mostrar por pantalla
    
    MostrarVoltajes(maxsen, medsen, rmssen, maxtri, medtri, rmstri);

    T1CONbits.TON=1;            //Encender el TMR1

       
}

// AMPLIACI�N - Voy a incrementar el ciclo de trabajo con un SWITCH.

//---------------------------------------------------------------------------
// Interrupci�n del SW1 - Rutina para incrementar el duty.
//---------------------------------------------------------------------------


void __attribute__((interrupt, auto_psv)) _INT1Interrupt(void)
{
	IFS1bits.INT1IF = 0;          // Limpiamos flag
    
    // Incrementamos la variable DUTY
    duty=duty+0.1;
        
    if (duty>=1){duty=0.5;} // Siempre partes del mismo duty, que es 0.5,
                           // as� que en cuanto pulses 4 veces resetea.
    
    // Llamamos otra vez a la funci�n con el nuevo duty
    GenPWM(duty);
}

// Voy a crear otra funci�n para obtener un valor de ciclo de trabajo menor de 0.5, 
// Uso otro Switch ahora

//---------------------------------------------------------------------------
// Interrupci�n del SW2 - Rutina para decrementar el duty.
//---------------------------------------------------------------------------

void __attribute__((interrupt, auto_psv)) _INT2Interrupt(void)
{
	IFS1bits.INT2IF = 0;          // Limpiamos flag
    
    // Decrementamos la variable DUTY
    duty=duty-0.1;
        
    if (duty<=0){duty=0.5;} // Siempre partes del mismo duty, que es 0.5,
                           // as� que en cuanto pulses 4 veces resetea.
    
    // Llamamos otra vez a la funci�n con el nuevo duty
    GenPWM(duty);
}

//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
    
    InitIO();
    InitADC();
    InitTMR3();

    ConfigInt();
    GenPWM(duty);
    InitTMR1();
    
    
    // Aqu� inicializamos el filtro
    // filtrar();
    FIRDelayInit(&filtroPasoBandaFilter); // Con el fichero .s generado
        
    T1CONbits.TON = 1; // Arrancamos el timer 1 para refresco LCD.
    T2CONbits.TON = 1; // Arrancamos el timer 2 que es el que va a controlar a la PWM.
    T3CONbits.TON = 1; // Arrancamos el timer 3 para muestreo correcto.
      
    while (1)   // bucle infinito
    {
   
    }
    
    return 0;
    
}// Main
