/* 
 * File:   Func.h
 * Author: AVA
 *
 */

/* En este archivo deben incluirse los prototipos de las funciones utilizadas en
 * FUNC.C.
 */

#ifndef FUNC_H
#define	FUNC_H

// EJEMPLO:
void InitIO(void);
void GenPWM(float);
void InitTMR1();
void InitTMR3();
void InitLCD(void);
void InitADC();
void ConfigInt();
float Avg(float *, unsigned int);
float Max(float *, unsigned int);
float Rms(float *, unsigned int);
void MostrarVoltajes(float, float, float, float, float, float);



// A�adir tantos prototipos como sea necesario.

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNC_H */

