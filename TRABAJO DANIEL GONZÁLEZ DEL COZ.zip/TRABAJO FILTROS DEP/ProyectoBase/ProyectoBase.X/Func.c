#include "Main.h"
#include "Func.h"
#include "LCD_display.h"

#include "dsp.h"
#include "math.h"

/* Este archivo contendr� la definici�n de las funciones auxiliares que se
 * necesiten para la ejecuci�n del c�digo.
 * Pueden a�adirse tantas como se quiera.
 * El objetivo es encapsular lo m�ximo posible el c�digo y reutilizar todas las+
 * funciones posibles.
 * En el archivo FUNC.H deber�n incluirse los prototipos de estas funciones.
 */

// Ejemplo:
// FUNCI�N PARA INICIALIZACI�N DE PUERTOS E/S
// Par�metros de entrada: ninguno (void).
// Par�metros de salida: ninguno (void).

void InitIO()
{             
    TRISB = 0xFFFF;                     
    TRISD = 0xFFF0;     
    LATD = 0xFFFF;      
    
    // PARA ACORDARME DE D�NDE ES CADA SE�AL 
    
    TRISBbits.TRISB10 = 1; // input se�al triangular
    TRISBbits.TRISB11 = 1; // input se�al senoidal
    
    TRISDbits.TRISD0 = 0;  // PWM
    
    return;
}// InitIO

//---------------------------------------------------------------------------
// InitTMR1 -- Refresca la informaci�n cada 500mseg del LCD
//---------------------------------------------------------------------------

void InitTMR1()
{   
    T1CON = 0;                    // Turn off Timer1 by clearing control register
	TMR1 = 0;                     // Start Timer1 at zero
	PR1 = (FCY/256)*0.5;          // Set period register value for 500mseg
    T1CON = 0x0030;               // Configure Timer1 (timer off, continue in IDLE, not gated, 1:256 prescaler, internal clock)    
    return;
}


//---------------------------------------------------------------------------
// InitTMR3 - Es el que me va a fijar la frecuencia de muestreo.
//---------------------------------------------------------------------------
void InitTMR3()
{   
    //Initialize Timer3 for 10ms period - Esto lo haremos para medir exactamente diez milisegundos de periodos.
    T3CON = 0;                    // Turn off Timer3 by clearing control register
	TMR3 = 0;                     // Start Timer1 at zero
	PR3 = (FCY/256)*0.0003333;        // Fijo la frecuencia de sampleo en 3000 Hz, cumpliendo as� con Nyquist y adem�s cogiendo cuatro muestras por periodo.
    T3CON = 0x0030;               // Configure Timer3 (timer off, continue in IDLE, not gated, 1:256 prescaler, internal clock)    
    return;
}

void InitLCD(void)
{
LCD_Display_Setup(); // INICIALIZA LCD
LCD_Display_Byte(HOME_CLEAR); // BORRA LCD
LCD_Display_Byte(CURSOR_ON); // PONE CURSOR
    
return;
}


//---------------------------------------------------------------------------
// InitADC. ADC intial configuration
//---------------------------------------------------------------------------
void InitADC()
{   
    // ADCON1 CONFIGURATION
    ADCON1bits.ADON = 0;        // Initially, stopped.
    ADCON1bits.ADSIDL = 0;      // No IDLE
    ADCON1bits.FORM = 0b00;     // Output format = unsigned integer - Esto es muy importante para el valor de las variables con las que voy a guardar los datos del ADC
    
    //Para controlar con el TMR3
    ADCON1bits.SSRC = 0b010;    // Source for triggering conversion = auto (111) con 010 disparo con TMR3
    ADCON1bits.ASAM = 1;        // Sampling after conversion ends

    // ADCON2 CONFIGURATION
    ADCON2bits.VCFG = 0b000;    // Vref+ = VDD, Vref- = VSS.
    ADCON2bits.SMPI = 0b1011;   // Interrupts after 12 conversion OJO, habr� que calcular la rutina de interrupci�n
    ADCON2bits.BUFM = 0;        // 16 words
    ADCON2bits.CSCNA = 1;
    ADCON2bits.ALTS = 0;
    ADCON2bits.BUFS = 0;
           
    // ADCON3 CONFIGURATION
    ADCON3bits.SAMC = 0b01111;   // 15�Tad 
    ADCON3bits.ADCS = 4;        // Clock Tad
    ADCON3bits.ADRC = 0;        // internal clock
    
    // ADCPCFG
    ADPCFG = 0xFFFF;	
    
    /*  Si quisiera muestrear los potenci�metros
     * 
    ADPCFGbits.PCFG6 = 0;    
    ADPCFGbits.PCFG5 = 0;
    ADPCFGbits.PCFG4 = 0;
     * 
    */
    
    // Las se�ales en RB11 y RB10 hay que muestrearlas
    // Est�n multiplexadas en AN11 y AN10
 
    ADPCFGbits.PCFG10 = 0;   
    ADPCFGbits.PCFG11 = 0;
     
    
    // ADCSSL
    ADCSSL = 0x0000;
 
    // Potenci�metros
    
    /*
    ADCSSLbits.CSSL6 = 1;// AN6 conversion configuro los bits anal�gicos. Qu� bits est�n disponibles y cuales no. 
    ADCSSLbits.CSSL5 = 1;
    ADCSSLbits.CSSL4 = 1;
    */
    
    ADCSSLbits.CSSL11 = 1;
    ADCSSLbits.CSSL10 = 1;
    
    
    ADCON1bits.ADON = 1;        // turn ADC ON, lo �ltimo qeu se hace, arrancalo.
    return;
}

//---------------------------------------------------------------------------
// ConfigInt(). For configuring interrupts
//---------------------------------------------------------------------------
void ConfigInt()
{ //Antes configur� el flag de cad para interrupci�n, ahora hay que dise�arla.
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Disable nesting interrputs 
  
    // Interruci�n CAD
    
    IFS0bits.ADIF = 0;              // Clear ADC flag
    IEC0bits.ADIE = 1;              // Enable ADC mask
    IPC2bits.ADIP = 5;              // ADC priority level
     
    //Interrupci�n TMR1
    
    IFS0bits.T1IF = 0;              // Clear TMR1 flag
    IEC0bits.T1IE = 1;              // Enable TMR1 mask
    IPC0bits.T1IP = 4;              // TMR1 priority level
    
    //Interrupci�n del SW1
    
    IFS1bits.INT1IF=0;              // Clear SW1 flag
    IEC1bits.INT1IE=1;              // Enable SW1 mask
    IPC4bits.INT1IP=3;              // SW1 priority level    
    
    //Interrupci�n del SW2
    
    IFS1bits.INT2IF=0;              // Clear SW2 flag
    IEC1bits.INT2IE=1;              // Enable SW2 mask
    IPC5bits.INT2IP=2;              // SW1 priority level 
    
    SET_CPU_IPL(1);                 // Set CPU priority level to a value below the lowest interrupt, menor quel CAD
    return;   
}

float Avg(float array[], unsigned int size){
    
    float suma;
    unsigned int i = 0;
    for(i=0;i<size;i++)
        suma = suma + array[i];
    
    return suma/(1.0*size);
}

float Max(float array[], unsigned int size){
    
    float max=0;
    unsigned int i = 0;
    for(i=0;i<size;i++)
    {
        if(max<array[i])
            max = array[i];
    }
    
    return max;
    }

float Rms(float array[], unsigned int size){
    
    float suma;
    float vrms;
    unsigned int i=0;

        for (i=0;i<size;i++){
        suma = suma + array[i];
    }
    
    vrms=sqrt((1/(1.0*size))*suma);
    return vrms;
    
}


void GenPWM(float duty){
    
    if (duty > 1) {duty = 0.9;} //M�X
    if (duty < 0) {duty = 0.1;} //MIN
    
    TMR2 = 0; // Vamos a usar el tmr2 para generar la PWM
    
    PR2 = FCY/737; //queremos 737 Hz.
    T2CON = 0x8000; //ojo que est�s poniendo prescaler a 1, arriba nada.
    
    // Con el comando anterior he arrancado el registro TON
    
    OC1CONbits.OCSIDL = 0;
    OC1CONbits.OCTSEL = 0;
    OC1CONbits.OCM = 0b110; //Pwm mode
    
    OC1RS = duty*PR2;
    
    return;
}

void MostrarVoltajes(float maxsen, float medsen, float rmssen, float maxtri, float medtri, float rmstri)
{

    //Tengo cuatro filas
    
    unsigned int tamfila=30;
        
    char fila1[tamfila], fila2[tamfila], fila3[tamfila], fila4[tamfila];

    //DATOS A MOSTRAR
    sprintf(fila1,"10:M=%.2fV;m=%.2fV\n",maxtri,medtri);
    sprintf(fila2,"10:rms=%.2fV\n",rmstri);
    sprintf(fila3,"11:M=%.2fV;m=%.2fV\n",maxsen,medsen);
    sprintf(fila4,"11:rms=%.2fV",rmssen);
    
    unsigned int TxIndex1=0;
    unsigned int TxIndex2=0;
    unsigned int TxIndex3=0;
    unsigned int TxIndex4=0;
    
   while(fila1[TxIndex1])
    {
        LCD_Display_Byte(WRITE_CHAR);      
        LCD_Display_Byte(fila1[TxIndex1++]); 
    }

    while(fila2[TxIndex2])
    {
        LCD_Display_Byte(WRITE_CHAR);       
        LCD_Display_Byte(fila2[TxIndex2++]);
    }

    while(fila3[TxIndex3])
    {
        LCD_Display_Byte(WRITE_CHAR);       
        LCD_Display_Byte(fila3[TxIndex3++]); 
    }

    while(fila4[TxIndex4])
    {
        LCD_Display_Byte(WRITE_CHAR);       
        LCD_Display_Byte(fila4[TxIndex4++]); 
    }
    
}

